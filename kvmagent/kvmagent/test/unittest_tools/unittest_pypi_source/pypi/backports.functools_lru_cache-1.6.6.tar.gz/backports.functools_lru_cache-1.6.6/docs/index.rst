Welcome to |project| documentation!
===================================

.. sidebar-links::
   :home:
   :pypi:

.. toctree::
   :maxdepth: 1

   history

.. tidelift-referral-banner::

.. automodule:: backports.functools_lru_cache
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
