Welcome to pathlib2's documentation!
====================================

:Release: |release|
:Date:    |today|

.. include:: ../README.rst
   :start-line: 6
