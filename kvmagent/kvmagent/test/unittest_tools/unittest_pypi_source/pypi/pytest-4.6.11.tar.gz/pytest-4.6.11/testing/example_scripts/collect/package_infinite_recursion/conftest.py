# -*- coding: utf-8 -*-
def pytest_ignore_collect(path):
    return False
