<!--
Thanks for submitting an issue!

Here's a quick checklist for what to provide:
-->

- [ ] a detailed description of the bug or suggestion
- [ ] output of `pip list` from the virtual environment you are using
- [ ] pytest and operating system versions
- [ ] minimal example if possible
