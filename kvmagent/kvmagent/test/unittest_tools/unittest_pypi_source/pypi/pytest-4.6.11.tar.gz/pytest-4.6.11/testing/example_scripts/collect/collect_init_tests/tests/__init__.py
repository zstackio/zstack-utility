# -*- coding: utf-8 -*-
def test_init():
    pass
