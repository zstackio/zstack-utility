# -*- coding: utf-8 -*-
def test_1(arg1):
    pass
