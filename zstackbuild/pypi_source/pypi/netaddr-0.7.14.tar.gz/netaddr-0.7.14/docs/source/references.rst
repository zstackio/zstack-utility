========================
Standards and References
========================

.. include:: ../../REFERENCES
