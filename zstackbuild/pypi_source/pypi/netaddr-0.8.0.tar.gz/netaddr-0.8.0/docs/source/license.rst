=======
License
=======

.. include:: ../../LICENSE
