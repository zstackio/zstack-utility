==================
Installing netaddr
==================

.. include:: ../../INSTALL
