===========================
What's new in netaddr 0.8.0
===========================

.. include:: ../../CHANGELOG
