import platform
import os

def update_library():
    arch = platform.machine()
    current_directory = os.path.dirname(os.path.abspath(__file__))
    lib_path = os.path.join(current_directory, "soc_handler.so")
    backup_path = os.path.join(current_directory, "soc_handler.so_" + arch)

    try:
        if not os.path.exists(backup_path):
            return

        if not os.path.exists(lib_path):
            print("rename")
            os.rename(backup_path, lib_path)

        so_stat_info = os.stat(lib_path)

        if os.path.exists(backup_path) and os.stat(backup_path).st_ctime != so_stat_info.st_ctime:
            os.remove(lib_path)
            os.rename(backup_path, lib_path)

    except Exception as e:
        print("Error: {}".format(e))

update_library()        
