from setuptools import setup, find_packages
setup(name="soc_handler",
      version='0.5',
      description='clinical trial information retriver',
      url='http://github.com/tongling/clinicaltrial',
      author='Ling',
      author_email='tonglingacademic@gmail.com',
      license='MIT',
      include_package_data=True,
      packages=find_packages(),
      zip_safe=True)
