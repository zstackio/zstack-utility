import platform
import os

arch = platform.machine()
current_directory = os.path.dirname(os.path.abspath(__file__))
lib_path = current_directory + "/soc_handler.so"

if os.path.exists(current_directory + "/soc_handler.so_" + arch) is False:
    return

if (os.path.exists(lib_path)) is False:
    print("rename")
    os.rename(current_directory + "/soc_handler.so_" + arch , lib_path)

so_stat_info = os.stat(lib_path)

if os.path.exists(current_directory + "/soc_handler.so_" + arch) is True:
    candidate_so_stat_info = os.stat(current_directory + "/soc_handler.so_" + arch)
    print(so_stat_info.st_ctime != candidate_so_stat_info.st_ctime)
    if so_stat_info.st_ctime != candidate_so_stat_info.st_ctime:
        os.remove(lib_path)
        os.rename(current_directory + "/soc_handler.so_" + arch , lib_path)
