# Used by pyinstaller to expose hidden imports

# Remove when trees module is removed. Ref #101.

hiddenimports = ['importlib_resources.trees']
