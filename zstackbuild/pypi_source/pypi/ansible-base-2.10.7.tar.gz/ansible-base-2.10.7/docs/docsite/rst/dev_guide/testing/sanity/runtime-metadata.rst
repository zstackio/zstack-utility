runtime-metadata.yml
====================

Validates the schema for:

* ansible-base's ``lib/ansible/config/ansible_builtin_runtime.yml``
* collection's ``meta/runtime.yml``
