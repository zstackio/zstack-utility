.. _all_modules_and_plugins:

Indexes of all modules and plugins
----------------------------------

.. toctree::
   :maxdepth: 1
   :caption: Plugin indexes
   :glob:

   index_*
