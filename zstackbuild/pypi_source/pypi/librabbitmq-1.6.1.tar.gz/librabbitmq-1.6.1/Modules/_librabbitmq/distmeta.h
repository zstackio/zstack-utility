#define PYRABBITMQ_VERSION "1.6.1"
#define PYRABBITMQ_AUTHOR "Ask Solem"
#define PYRABBITMQ_CONTACT "ask@celeryproject.org"
#define PYRABBITMQ_HOMEPAGE "http://github.com/celery/librabbitmq"
