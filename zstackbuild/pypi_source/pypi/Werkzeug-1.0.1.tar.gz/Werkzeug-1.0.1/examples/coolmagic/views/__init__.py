# -*- coding: utf-8 -*-
"""
    coolmagic.views
    ~~~~~~~~~~~~~~~

    This module collects and assambles the urls.

    :copyright: 2007 Pallets
    :license: BSD-3-Clause
"""
