============================
 Frequently Asked Questions
============================

Questions
=========

Q: Message.reject doesn't work?
--------------------------------------
**Answer**: Earlier versions of RabbitMQ did not implement ``basic.reject``,
so make sure your version is recent enough to support it.

Q: Message.requeue doesn't work?
--------------------------------------

**Answer**: See _`Message.reject doesn't work?`
